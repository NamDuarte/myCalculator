﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Calculator_Nam
{
    public partial class Form1 : Form
    {
        bool operation_performed = false;
        double first_Number;
        double second_Number;
        double Result;
        string user_Operation;
        double memory_value;
        int hist_counter = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox_operation.Items.Add("Add");
            comboBox_operation.Items.Add("Subtract");
            comboBox_operation.Items.Add("Multiply");
            comboBox_operation.Items.Add("Divide");

            solution_textBox.Text = "0";
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button num_button = (Button)sender;

            if ((solution_textBox.Text == "0") || (operation_performed))
                solution_textBox.Text = "";

            if (num_button.Text == ".")
            {
                if (!solution_textBox.Text.Contains("."))
                    solution_textBox.Text = solution_textBox.Text + num_button.Text;
            }
            else
            {
                solution_textBox.Text = solution_textBox.Text + num_button.Text;
            }
            operation_performed = false;
        }
        private void button_delete_Click(object sender, EventArgs e)
        {
            double tempNum = double.Parse(solution_textBox.Text);

            if (tempNum != 0)
            {
                solution_textBox.Text = solution_textBox.Text.Substring(0, (solution_textBox.TextLength - 1));
            }
        }
        private void button_clear_Click(object sender, EventArgs e)
        {
            first_Number = 0;
            solution_textBox.Text = "0";
            comboBox_operation.Text = "";

            hist_counter = hist_counter + 1;
            string count = Convert.ToString(hist_counter);

            richTextBox_history.AppendText(count);
            richTextBox_history.AppendText("\tClear\t\t0\n");

        }
        private void button_plus_Click(object sender, EventArgs e)
        {
            if (!solution_textBox.Text.Contains("-"))
                solution_textBox.Text = "-" + solution_textBox.Text;
            else if (solution_textBox.Text.Contains("-"))
                solution_textBox.Text = solution_textBox.Text.Substring(1);

        }
        private void comboBox_operation_SelectedIndexChanged(object sender, EventArgs e)
        {
            string oper = comboBox_operation.Text;

            first_Number = Convert.ToDouble(solution_textBox.Text);

            switch (oper)
            {
                case "Add":
                    user_Operation = "addition";
                    break;
                case "Subtract":
                    user_Operation = "subtraction";
                    break;
                case "Multiply":
                    user_Operation = "multiplication";
                    break;
                case "Divide":
                    user_Operation = "division";
                    break;
            }
            solution_textBox.Text = "0";
        }

        private void button_equals_Click(object sender, EventArgs e)
        {
            second_Number = Convert.ToDouble(solution_textBox.Text);
            operation_performed = true;

            if (user_Operation == "addition")
            {
                Result = first_Number + second_Number;
                solution_textBox.Text = Convert.ToString(Result);
            }

            if (user_Operation == "subtraction")
            {
                Result = first_Number - second_Number;
                solution_textBox.Text = Convert.ToString(Result);
            }

            if (user_Operation == "multiplication")
            {
                Result = first_Number * second_Number; 
                solution_textBox.Text = Convert.ToString(Result);
            }

            if (user_Operation == "division")
            {
                if (second_Number == 0)
                {
                    solution_textBox.Text = "Cannot divide number by zero";
                }

                else
                {
                    Result = first_Number / second_Number;
                    solution_textBox.Text = Convert.ToString(Result);
                }
            }

            comboBox_operation.Text = "";

            hist_counter = hist_counter + 1;
            string count = Convert.ToString(hist_counter);
            richTextBox_history.AppendText(count);

            if (user_Operation != "")
            {
                richTextBox_history.AppendText("\t" + user_Operation);

                if (user_Operation == "addition" || user_Operation == "division")
                {
                    richTextBox_history.AppendText("\t\t");
                    richTextBox_history.AppendText(Result + "\n");
                }
                else
                    richTextBox_history.AppendText("\t" + Result + "\n");
            }
            else
                richTextBox_history.AppendText("\tEqual\t\tError!\n");

            label_hist.Text = "";
            user_Operation = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            double tempCurrent = Convert.ToDouble(solution_textBox.Text);

            memory_value = memory_value + tempCurrent;
            string temp_mem = Convert.ToString(memory_value);
            label_mem.Text = ("");
            list_memory.Items.Clear();
            list_memory.Items.Add(temp_mem);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double tempCurrent = Convert.ToDouble(solution_textBox.Text);
            memory_value = memory_value - tempCurrent;
            string temp_mem = Convert.ToString(memory_value);
            label_mem.Text = ("");
            list_memory.Items.Clear();
            list_memory.Items.Add(temp_mem);
        }

        private void solution_textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button_memRec_Click(object sender, EventArgs e)
        {
            solution_textBox.Text = Convert.ToString(memory_value);
        }

        private void button_memClear_Click(object sender, EventArgs e)
        {
            memory_value = 0;
            list_memory.Items.Clear();
            label_mem.Text = ("There's nothing saved in memory");
        }

        //These are the Menu Bar items and buttons
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            solution_textBox.Text = "";
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetData(DataFormats.Text, solution_textBox.Text);
        }
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            solution_textBox.Text = Clipboard.GetText();
        }

        private void button_clrHist_Click(object sender, EventArgs e)
        {
            richTextBox_history.Clear();
            if (label_hist.Text == "")
            {
                label_hist.Text = "There's no history yet";
            }
            richTextBox_history.ScrollBars = 0;

            hist_counter = 0;
        }

        private void exportToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\Public\Documents\History.txt";

            TextWriter writer = new StreamWriter(path);

            writer.Write(richTextBox_history.Text);
            MessageBox.Show("History has been exported!");
            writer.Close();
        }

        private void importFromTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stream myStream;
            OpenFileDialog openDialog = new OpenFileDialog();

            if (openDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if ((myStream = openDialog.OpenFile()) != null)
                {
                    string fileName = openDialog.FileName;
                    string hist = File.ReadAllText(fileName);
                    richTextBox_history.Text = hist;
                    MessageBox.Show("Import Completed.");
                }
            }

            label_hist.Text = "";
        }
    }
}
