﻿namespace Calculator_Nam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.solution_textBox = new System.Windows.Forms.TextBox();
            this.button_one = new System.Windows.Forms.Button();
            this.button_three = new System.Windows.Forms.Button();
            this.button_nine = new System.Windows.Forms.Button();
            this.button_eight = new System.Windows.Forms.Button();
            this.button_seven = new System.Windows.Forms.Button();
            this.button_six = new System.Windows.Forms.Button();
            this.button_five = new System.Windows.Forms.Button();
            this.button_four = new System.Windows.Forms.Button();
            this.button_zero = new System.Windows.Forms.Button();
            this.button_decimal = new System.Windows.Forms.Button();
            this.button_equals = new System.Windows.Forms.Button();
            this.comboBox_operation = new System.Windows.Forms.ComboBox();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_plus = new System.Windows.Forms.Button();
            this.button_two = new System.Windows.Forms.Button();
            this.button_memAd = new System.Windows.Forms.Button();
            this.button_memMin = new System.Windows.Forms.Button();
            this.button_memRec = new System.Windows.Forms.Button();
            this.button_memClear = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importFromTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.list_memory = new System.Windows.Forms.ListView();
            this.richTextBox_history = new System.Windows.Forms.RichTextBox();
            this.button_clrHist = new System.Windows.Forms.Button();
            this.label_hist = new System.Windows.Forms.Label();
            this.label_mem = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // solution_textBox
            // 
            this.solution_textBox.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.solution_textBox.Location = new System.Drawing.Point(13, 44);
            this.solution_textBox.Name = "solution_textBox";
            this.solution_textBox.Size = new System.Drawing.Size(318, 32);
            this.solution_textBox.TabIndex = 35;
            // 
            // button_one
            // 
            this.button_one.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_one.Location = new System.Drawing.Point(13, 132);
            this.button_one.Name = "button_one";
            this.button_one.Size = new System.Drawing.Size(75, 48);
            this.button_one.TabIndex = 1;
            this.button_one.Text = "1";
            this.button_one.UseVisualStyleBackColor = true;
            this.button_one.Click += new System.EventHandler(this.button_Click);
            // 
            // button_three
            // 
            this.button_three.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_three.Location = new System.Drawing.Point(175, 132);
            this.button_three.Name = "button_three";
            this.button_three.Size = new System.Drawing.Size(75, 48);
            this.button_three.TabIndex = 3;
            this.button_three.Text = "3";
            this.button_three.UseVisualStyleBackColor = true;
            this.button_three.Click += new System.EventHandler(this.button_Click);
            // 
            // button_nine
            // 
            this.button_nine.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_nine.Location = new System.Drawing.Point(175, 254);
            this.button_nine.Name = "button_nine";
            this.button_nine.Size = new System.Drawing.Size(75, 48);
            this.button_nine.TabIndex = 4;
            this.button_nine.Text = "9";
            this.button_nine.UseVisualStyleBackColor = true;
            this.button_nine.Click += new System.EventHandler(this.button_Click);
            // 
            // button_eight
            // 
            this.button_eight.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_eight.Location = new System.Drawing.Point(94, 254);
            this.button_eight.Name = "button_eight";
            this.button_eight.Size = new System.Drawing.Size(75, 48);
            this.button_eight.TabIndex = 5;
            this.button_eight.Text = "8";
            this.button_eight.UseVisualStyleBackColor = true;
            this.button_eight.Click += new System.EventHandler(this.button_Click);
            // 
            // button_seven
            // 
            this.button_seven.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_seven.Location = new System.Drawing.Point(13, 254);
            this.button_seven.Name = "button_seven";
            this.button_seven.Size = new System.Drawing.Size(75, 48);
            this.button_seven.TabIndex = 6;
            this.button_seven.Text = "7";
            this.button_seven.UseVisualStyleBackColor = true;
            this.button_seven.Click += new System.EventHandler(this.button_Click);
            // 
            // button_six
            // 
            this.button_six.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_six.Location = new System.Drawing.Point(175, 193);
            this.button_six.Name = "button_six";
            this.button_six.Size = new System.Drawing.Size(75, 48);
            this.button_six.TabIndex = 7;
            this.button_six.Text = "6";
            this.button_six.UseVisualStyleBackColor = true;
            this.button_six.Click += new System.EventHandler(this.button_Click);
            // 
            // button_five
            // 
            this.button_five.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_five.Location = new System.Drawing.Point(94, 193);
            this.button_five.Name = "button_five";
            this.button_five.Size = new System.Drawing.Size(75, 48);
            this.button_five.TabIndex = 8;
            this.button_five.Text = "5";
            this.button_five.UseVisualStyleBackColor = true;
            this.button_five.Click += new System.EventHandler(this.button_Click);
            // 
            // button_four
            // 
            this.button_four.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_four.Location = new System.Drawing.Point(13, 193);
            this.button_four.Name = "button_four";
            this.button_four.Size = new System.Drawing.Size(75, 48);
            this.button_four.TabIndex = 9;
            this.button_four.Text = "4";
            this.button_four.UseVisualStyleBackColor = true;
            this.button_four.Click += new System.EventHandler(this.button_Click);
            // 
            // button_zero
            // 
            this.button_zero.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_zero.Location = new System.Drawing.Point(13, 311);
            this.button_zero.Name = "button_zero";
            this.button_zero.Size = new System.Drawing.Size(75, 48);
            this.button_zero.TabIndex = 10;
            this.button_zero.Text = "0";
            this.button_zero.UseVisualStyleBackColor = true;
            this.button_zero.Click += new System.EventHandler(this.button_Click);
            // 
            // button_decimal
            // 
            this.button_decimal.Location = new System.Drawing.Point(94, 311);
            this.button_decimal.Name = "button_decimal";
            this.button_decimal.Size = new System.Drawing.Size(75, 48);
            this.button_decimal.TabIndex = 35;
            this.button_decimal.Text = ".";
            this.button_decimal.Click += new System.EventHandler(this.button_Click);
            // 
            // button_equals
            // 
            this.button_equals.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_equals.Location = new System.Drawing.Point(256, 254);
            this.button_equals.Name = "button_equals";
            this.button_equals.Size = new System.Drawing.Size(75, 105);
            this.button_equals.TabIndex = 12;
            this.button_equals.Text = "=";
            this.button_equals.UseVisualStyleBackColor = true;
            this.button_equals.Click += new System.EventHandler(this.button_equals_Click);
            // 
            // comboBox_operation
            // 
            this.comboBox_operation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_operation.FormattingEnabled = true;
            this.comboBox_operation.Location = new System.Drawing.Point(13, 90);
            this.comboBox_operation.Name = "comboBox_operation";
            this.comboBox_operation.Size = new System.Drawing.Size(318, 26);
            this.comboBox_operation.TabIndex = 19;
            this.comboBox_operation.SelectedIndexChanged += new System.EventHandler(this.comboBox_operation_SelectedIndexChanged);
            // 
            // button_clear
            // 
            this.button_clear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clear.Location = new System.Drawing.Point(256, 193);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(75, 48);
            this.button_clear.TabIndex = 14;
            this.button_clear.Text = "Clear";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_delete
            // 
            this.button_delete.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete.Location = new System.Drawing.Point(256, 132);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(75, 48);
            this.button_delete.TabIndex = 15;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_plus
            // 
            this.button_plus.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_plus.Location = new System.Drawing.Point(175, 311);
            this.button_plus.Name = "button_plus";
            this.button_plus.Size = new System.Drawing.Size(75, 48);
            this.button_plus.TabIndex = 16;
            this.button_plus.Text = "+/-";
            this.button_plus.UseVisualStyleBackColor = true;
            this.button_plus.Click += new System.EventHandler(this.button_plus_Click);
            // 
            // button_two
            // 
            this.button_two.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_two.Location = new System.Drawing.Point(94, 132);
            this.button_two.Name = "button_two";
            this.button_two.Size = new System.Drawing.Size(75, 48);
            this.button_two.TabIndex = 18;
            this.button_two.Text = "2";
            this.button_two.UseVisualStyleBackColor = true;
            this.button_two.Click += new System.EventHandler(this.button_Click);
            // 
            // button_memAd
            // 
            this.button_memAd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_memAd.Location = new System.Drawing.Point(13, 369);
            this.button_memAd.Name = "button_memAd";
            this.button_memAd.Size = new System.Drawing.Size(75, 48);
            this.button_memAd.TabIndex = 20;
            this.button_memAd.Text = "M+";
            this.button_memAd.UseVisualStyleBackColor = true;
            this.button_memAd.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_memMin
            // 
            this.button_memMin.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_memMin.Location = new System.Drawing.Point(94, 369);
            this.button_memMin.Name = "button_memMin";
            this.button_memMin.Size = new System.Drawing.Size(75, 48);
            this.button_memMin.TabIndex = 21;
            this.button_memMin.Text = "M-";
            this.button_memMin.UseVisualStyleBackColor = true;
            this.button_memMin.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_memRec
            // 
            this.button_memRec.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_memRec.Location = new System.Drawing.Point(175, 369);
            this.button_memRec.Name = "button_memRec";
            this.button_memRec.Size = new System.Drawing.Size(75, 48);
            this.button_memRec.TabIndex = 24;
            this.button_memRec.Text = "MR";
            this.button_memRec.Click += new System.EventHandler(this.button_memRec_Click);
            // 
            // button_memClear
            // 
            this.button_memClear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_memClear.Location = new System.Drawing.Point(256, 369);
            this.button_memClear.Name = "button_memClear";
            this.button_memClear.Size = new System.Drawing.Size(75, 48);
            this.button_memClear.TabIndex = 23;
            this.button_memClear.Text = "MC";
            this.button_memClear.UseVisualStyleBackColor = true;
            this.button_memClear.Click += new System.EventHandler(this.button_memClear_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.historyToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(604, 25);
            this.menuStrip1.TabIndex = 25;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(39, 21);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem});
            this.editToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportToTextToolStripMenuItem,
            this.importFromTextToolStripMenuItem});
            this.historyToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(61, 21);
            this.historyToolStripMenuItem.Text = "History";
            // 
            // exportToTextToolStripMenuItem
            // 
            this.exportToTextToolStripMenuItem.Name = "exportToTextToolStripMenuItem";
            this.exportToTextToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.exportToTextToolStripMenuItem.Text = "Export to Text";
            this.exportToTextToolStripMenuItem.Click += new System.EventHandler(this.exportToTextToolStripMenuItem_Click);
            // 
            // importFromTextToolStripMenuItem
            // 
            this.importFromTextToolStripMenuItem.Name = "importFromTextToolStripMenuItem";
            this.importFromTextToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.importFromTextToolStripMenuItem.Text = "Import from Text";
            this.importFromTextToolStripMenuItem.Click += new System.EventHandler(this.importFromTextToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(352, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 18);
            this.label1.TabIndex = 28;
            this.label1.Text = "History";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(352, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 18);
            this.label2.TabIndex = 29;
            this.label2.Text = "Memory";
            // 
            // list_memory
            // 
            this.list_memory.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.list_memory.HideSelection = false;
            this.list_memory.Location = new System.Drawing.Point(356, 275);
            this.list_memory.Name = "list_memory";
            this.list_memory.Size = new System.Drawing.Size(228, 142);
            this.list_memory.TabIndex = 30;
            this.list_memory.UseCompatibleStateImageBehavior = false;
            // 
            // richTextBox_history
            // 
            this.richTextBox_history.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox_history.Location = new System.Drawing.Point(355, 66);
            this.richTextBox_history.Name = "richTextBox_history";
            this.richTextBox_history.Size = new System.Drawing.Size(229, 175);
            this.richTextBox_history.TabIndex = 31;
            this.richTextBox_history.Text = "";
            // 
            // button_clrHist
            // 
            this.button_clrHist.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_clrHist.Location = new System.Drawing.Point(509, 42);
            this.button_clrHist.Name = "button_clrHist";
            this.button_clrHist.Size = new System.Drawing.Size(75, 18);
            this.button_clrHist.TabIndex = 32;
            this.button_clrHist.Text = "Clear";
            this.button_clrHist.UseVisualStyleBackColor = true;
            this.button_clrHist.Click += new System.EventHandler(this.button_clrHist_Click);
            // 
            // label_hist
            // 
            this.label_hist.AutoSize = true;
            this.label_hist.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_hist.Location = new System.Drawing.Point(365, 75);
            this.label_hist.Name = "label_hist";
            this.label_hist.Size = new System.Drawing.Size(0, 15);
            this.label_hist.TabIndex = 33;
            // 
            // label_mem
            // 
            this.label_mem.AutoSize = true;
            this.label_mem.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mem.Location = new System.Drawing.Point(368, 288);
            this.label_mem.Name = "label_mem";
            this.label_mem.Size = new System.Drawing.Size(0, 12);
            this.label_mem.TabIndex = 34;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 443);
            this.Controls.Add(this.label_mem);
            this.Controls.Add(this.label_hist);
            this.Controls.Add(this.button_clrHist);
            this.Controls.Add(this.richTextBox_history);
            this.Controls.Add(this.list_memory);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_memClear);
            this.Controls.Add(this.button_memRec);
            this.Controls.Add(this.button_memMin);
            this.Controls.Add(this.button_memAd);
            this.Controls.Add(this.button_two);
            this.Controls.Add(this.button_plus);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.comboBox_operation);
            this.Controls.Add(this.button_equals);
            this.Controls.Add(this.button_decimal);
            this.Controls.Add(this.button_zero);
            this.Controls.Add(this.button_four);
            this.Controls.Add(this.button_five);
            this.Controls.Add(this.button_six);
            this.Controls.Add(this.button_seven);
            this.Controls.Add(this.button_eight);
            this.Controls.Add(this.button_nine);
            this.Controls.Add(this.button_three);
            this.Controls.Add(this.button_one);
            this.Controls.Add(this.solution_textBox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "myCalculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox solution_textBox;
        private System.Windows.Forms.Button button_one;
        private System.Windows.Forms.Button button_three;
        private System.Windows.Forms.Button button_nine;
        private System.Windows.Forms.Button button_eight;
        private System.Windows.Forms.Button button_seven;
        private System.Windows.Forms.Button button_six;
        private System.Windows.Forms.Button button_five;
        private System.Windows.Forms.Button button_four;
        private System.Windows.Forms.Button button_zero;
        private System.Windows.Forms.Button button_decimal;
        private System.Windows.Forms.Button button_equals;
        private System.Windows.Forms.ComboBox comboBox_operation;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_plus;
        private System.Windows.Forms.Button button_two;
        private System.Windows.Forms.Button button_memAd;
        private System.Windows.Forms.Button button_memMin;
        private System.Windows.Forms.Button button_memRec;
        private System.Windows.Forms.Button button_memClear;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportToTextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importFromTextToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView list_memory;
        private System.Windows.Forms.RichTextBox richTextBox_history;
        private System.Windows.Forms.Button button_clrHist;
        private System.Windows.Forms.Label label_hist;
        private System.Windows.Forms.Label label_mem;
    }
}

